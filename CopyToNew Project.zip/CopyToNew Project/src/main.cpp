#include <iostream>

int main()
{
	std::cout<<"HelloWorld"<<std::endl;
	return 0;
}